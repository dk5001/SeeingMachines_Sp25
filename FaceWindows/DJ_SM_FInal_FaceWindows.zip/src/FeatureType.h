#pragma once

enum class FeatureType {
    EYE_LEFT,
    EYE_RIGHT,
    NOSE,
    MOUTH
};


// what abt giant transparent window + face parts in bounding boxes, instead of individual windows